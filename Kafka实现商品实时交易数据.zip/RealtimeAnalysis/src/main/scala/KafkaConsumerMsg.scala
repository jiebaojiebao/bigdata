import kafka.serializer.StringDecoder
import com.alibaba.fastjson.{JSON, JSONObject}
import org.apache.spark.streaming.dstream.{DStream, InputDStream}
import org.apache.spark.streaming.kafka.KafkaUtils
import org.apache.spark.streaming.{Seconds, StreamingContext}
import org.apache.spark.{SparkConf, SparkContext}

object KafkaConsumerMsg {
  def main(args: Array[String]): Unit = {
    //创建sparkConf对象
    val sparkConf = new SparkConf().setMaster("local[2]").setAppName("KafkaConsumerMsg")
    //创建SparkContex对象
    val sparkContext = new SparkContext(sparkConf)
    //设置日志级别
    sparkContext.setLogLevel("warn")
    //获取StreamingContext对象，5秒一个批次
    val ssc = new StreamingContext(sparkContext, Seconds(5))
    //设置Kafka参数
    val kafkaParams = Map("bootstrap.servers" -> "bigdata01:9092,bigdata02:9092,bigdata03:9092",
      "group.id" -> "spark-receiver")
    //指定Topic相关信息
    val topics = Set("logtoflume")
    //通过KafkaUtils.createDirectStream利用低级api接受kafka数据
    val kafkaDstream: InputDStream[(String, String)] =
      KafkaUtils.createDirectStream
        [String, String, StringDecoder, StringDecoder](ssc, kafkaParams, topics)
    //获取Kafka中Topic数据，并解析JSON格式数据
    val events: DStream[JSONObject] = kafkaDstream.flatMap(line => Some(JSON.parseObject(line._2)))
    //按照productID进行分组统计个数和总价格
    val orders: DStream[(String, Int, Long)] = events.map(x => (x.getString("productId"), x.getLong("productPrice"))).groupByKey().map(x => (x._1, x._2.size, x._2.reduceLeft(_ + _)))
    //打印输出
    orders.foreachRDD(x =>
      x.foreachPartition(partition =>
        partition.foreach(x => {
          println("productId="
            + x._1 + " count=" + x._2 + " productPricrice=" + x._3)

        })
      )
    )
    ssc.start()
    ssc.awaitTermination()
  }
}
