

import org.apache.log4j.Logger;

public class LoggerGenerator {
    private static Logger logger = Logger.getLogger( LoggerGenerator.class );

    public static void main(String[] args) {
        while (true) {

            PaymentInfo p = new PaymentInfo();
            String message = p.random();
            logger.info( message );
            try {
                Thread.sleep( 6000 );
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
    }
}
